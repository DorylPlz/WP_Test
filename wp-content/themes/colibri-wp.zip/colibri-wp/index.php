<?php

get_header();

colibriwp_theme()->get( 'main' )->render();

get_footer();
