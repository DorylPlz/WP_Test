<div class="post-meta small muted space-bottom-small">
    <span class="date"><?php the_time( get_option( 'date_format' ) ); ?></span>
</div>
