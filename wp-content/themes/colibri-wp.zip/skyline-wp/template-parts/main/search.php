<div data-colibri-id="25-m1" class="style-138 style-local-25-m1 position-relative">
  <div data-colibri-id="25-m2" class="h-row-container gutters-row-lg-3 gutters-row-md-3 gutters-row-2 gutters-row-v-lg-3 gutters-row-v-md-3 gutters-row-v-3 colibri-dynamic-list style-139 style-local-25-m2 position-relative">
    <div class="h-row justify-content-lg-start justify-content-md-start justify-content-start align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-3 gutters-col-md-3 gutters-col-2 gutters-col-v-lg-3 gutters-col-v-md-3 gutters-col-v-3 style-139-row style-local-25-m2-row">
      <?php colibriwp_theme()->get('search-loop')->render(); ?>
    </div>
  </div>
  <?php colibriwp_layout_wrapper(array (
    'name' => 'navigation_container',
    'slug' => 'navigation-container-3',
  )); ?>
  <div data-colibri-id="25-m21" id="search-results" class="h-row-container gutters-row-lg-0 gutters-row-md-0 gutters-row-0 gutters-row-v-lg-0 gutters-row-v-md-0 gutters-row-v-0 style-157 style-local-25-m21 position-relative">
    <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-0 gutters-col-md-0 gutters-col-0 gutters-col-v-lg-0 gutters-col-v-md-0 gutters-col-v-0">
      <div class="h-column h-column-container d-flex h-col-lg-12 h-col-md-12 h-col-12 style-158-outer style-local-25-m22-outer">
        <div data-colibri-id="25-m22" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-158 style-local-25-m22 position-relative">
          <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start"></div>
        </div>
      </div>
    </div>
  </div>
</div>
